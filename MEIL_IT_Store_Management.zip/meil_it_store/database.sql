CREATE DATABASE IF NOT EXISTS meil_it_store CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE meil_it_store;

CREATE TABLE users (
 id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(80) UNIQUE NOT NULL,
 password_hash VARCHAR(255) NOT NULL, full_name VARCHAR(150) NOT NULL,
 role ENUM('admin','store','viewer') NOT NULL DEFAULT 'admin',
 active TINYINT(1) NOT NULL DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO users(username,password_hash,full_name,role) VALUES
('admin','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','System Administrator','admin');

CREATE TABLE departments(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) UNIQUE NOT NULL);
INSERT INTO departments(name) VALUES ('Planning'),('QA/QC'),('Mechanical'),('Stores'),('Civil'),('Electrical'),('IT'),('Admin'),('AMG'),('Safety'),('HR/IR');

CREATE TABLE locations(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(120) UNIQUE NOT NULL);
INSERT INTO locations(name) VALUES ('Main Store'),('IT Store'),('Main Plant'),('Township'),('CTL'),('Steel Yard'),('Batching Plant'),('Office'),('LC-1');

CREATE TABLE categories(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) UNIQUE NOT NULL);
INSERT INTO categories(name) VALUES ('Computers'),('Networking'),('Printers & Scanners'),('CCTV & Surveillance'),('Peripherals'),('Cables & Consumables'),('Power & UPS'),('Software & Licences'),('Other');

CREATE TABLE vendors(
 id INT AUTO_INCREMENT PRIMARY KEY, vendor_name VARCHAR(180) NOT NULL,
 vendor_type ENUM('Local','HO','Other') NOT NULL DEFAULT 'Local',
 contact_person VARCHAR(150), phone VARCHAR(50), email VARCHAR(150),
 address TEXT, supplied_items TEXT, approved TINYINT(1) NOT NULL DEFAULT 0,
 notes TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE employees(
 id INT AUTO_INCREMENT PRIMARY KEY, employee_code VARCHAR(80) UNIQUE,
 employee_name VARCHAR(180) NOT NULL, department_id INT NULL,
 designation VARCHAR(120), phone VARCHAR(50), active TINYINT(1) NOT NULL DEFAULT 1,
 FOREIGN KEY(department_id) REFERENCES departments(id) ON DELETE SET NULL
);

CREATE TABLE items(
 id INT AUTO_INCREMENT PRIMARY KEY, item_code VARCHAR(80) UNIQUE NOT NULL,
 item_name VARCHAR(180) NOT NULL, category_id INT NULL, brand VARCHAR(120),
 model_no VARCHAR(120), specifications TEXT, unit VARCHAR(40) NOT NULL DEFAULT 'Nos',
 min_stock DECIMAL(12,2) NOT NULL DEFAULT 0, default_location_id INT NULL,
 is_serialized TINYINT(1) NOT NULL DEFAULT 0, active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE SET NULL,
 FOREIGN KEY(default_location_id) REFERENCES locations(id) ON DELETE SET NULL
);

CREATE TABLE indents(
 id INT AUTO_INCREMENT PRIMARY KEY, indent_no VARCHAR(50) UNIQUE NOT NULL,
 indent_date DATE NOT NULL, requested_by VARCHAR(150), department_id INT NULL,
 purpose TEXT, status VARCHAR(50) NOT NULL DEFAULT 'Draft',
 document_notes TEXT, created_by INT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(department_id) REFERENCES departments(id) ON DELETE SET NULL,
 FOREIGN KEY(created_by) REFERENCES users(id)
);
CREATE TABLE indent_lines(
 id INT AUTO_INCREMENT PRIMARY KEY, indent_id INT NOT NULL, item_id INT NULL,
 description VARCHAR(220) NOT NULL, specifications TEXT, qty DECIMAL(12,2) NOT NULL,
 unit VARCHAR(40) DEFAULT 'Nos', procurement_type ENUM('Local','HO') NOT NULL,
 estimated_rate DECIMAL(12,2) DEFAULT 0, line_status VARCHAR(50) DEFAULT 'Pending',
 FOREIGN KEY(indent_id) REFERENCES indents(id) ON DELETE CASCADE,
 FOREIGN KEY(item_id) REFERENCES items(id) ON DELETE SET NULL
);

CREATE TABLE iocs(
 id INT AUTO_INCREMENT PRIMARY KEY, ioc_no VARCHAR(80) NOT NULL,
 ioc_date DATE NULL, indent_id INT NOT NULL, ho_status VARCHAR(50) DEFAULT 'Pending',
 confirmation_date DATE NULL, remarks TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(indent_id) REFERENCES indents(id) ON DELETE CASCADE
);

CREATE TABLE procurement(
 id INT AUTO_INCREMENT PRIMARY KEY, procurement_no VARCHAR(50) UNIQUE NOT NULL,
 indent_id INT NOT NULL, ioc_id INT NULL, procurement_type ENUM('Local','HO') NOT NULL,
 vendor_id INT NULL, approval_status VARCHAR(50) DEFAULT 'Pending',
 purchase_order_no VARCHAR(100), purchase_date DATE NULL, amount DECIMAL(14,2) DEFAULT 0,
 remarks TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(indent_id) REFERENCES indents(id) ON DELETE CASCADE,
 FOREIGN KEY(ioc_id) REFERENCES iocs(id) ON DELETE SET NULL,
 FOREIGN KEY(vendor_id) REFERENCES vendors(id) ON DELETE SET NULL
);

CREATE TABLE assets(
 id INT AUTO_INCREMENT PRIMARY KEY, asset_tag VARCHAR(80) UNIQUE NOT NULL,
 item_id INT NOT NULL, serial_no VARCHAR(150), service_tag VARCHAR(150),
 mac_address VARCHAR(80), imei VARCHAR(80), brand VARCHAR(120), model_no VARCHAR(120),
 specifications TEXT, warranty_expiry DATE NULL, purchase_cost DECIMAL(12,2) DEFAULT 0,
 location_id INT NULL, status ENUM('Available','Issued','Damaged','Under Repair','Disposed') DEFAULT 'Available',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(item_id) REFERENCES items(id), FOREIGN KEY(location_id) REFERENCES locations(id) ON DELETE SET NULL
);

CREATE TABLE inward_receipts(
 id INT AUTO_INCREMENT PRIMARY KEY, inward_no VARCHAR(50) UNIQUE NOT NULL,
 inward_date DATE NOT NULL, indent_id INT NULL, ioc_id INT NULL, procurement_id INT NULL,
 store_inward_ref VARCHAR(100), delivery_ref VARCHAR(120), received_from VARCHAR(180),
 remarks TEXT, created_by INT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(indent_id) REFERENCES indents(id) ON DELETE SET NULL,
 FOREIGN KEY(ioc_id) REFERENCES iocs(id) ON DELETE SET NULL,
 FOREIGN KEY(procurement_id) REFERENCES procurement(id) ON DELETE SET NULL,
 FOREIGN KEY(created_by) REFERENCES users(id)
);
CREATE TABLE inward_lines(
 id INT AUTO_INCREMENT PRIMARY KEY, inward_id INT NOT NULL, item_id INT NOT NULL,
 qty DECIMAL(12,2) NOT NULL, unit_cost DECIMAL(12,2) DEFAULT 0,
 serial_no VARCHAR(150), asset_tag VARCHAR(80), location_id INT NULL, condition_status VARCHAR(40) DEFAULT 'Good',
 FOREIGN KEY(inward_id) REFERENCES inward_receipts(id) ON DELETE CASCADE,
 FOREIGN KEY(item_id) REFERENCES items(id), FOREIGN KEY(location_id) REFERENCES locations(id) ON DELETE SET NULL
);

CREATE TABLE issues(
 id INT AUTO_INCREMENT PRIMARY KEY, issue_no VARCHAR(50) UNIQUE NOT NULL,
 issue_date DATE NOT NULL, employee_id INT NULL, department_id INT NULL,
 issued_to VARCHAR(180), install_location VARCHAR(180), purpose TEXT,
 signed_by VARCHAR(150), remarks TEXT, created_by INT NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE SET NULL,
 FOREIGN KEY(department_id) REFERENCES departments(id) ON DELETE SET NULL,
 FOREIGN KEY(created_by) REFERENCES users(id)
);
CREATE TABLE issue_lines(
 id INT AUTO_INCREMENT PRIMARY KEY, issue_id INT NOT NULL, item_id INT NOT NULL,
 asset_id INT NULL, qty DECIMAL(12,2) NOT NULL,
 FOREIGN KEY(issue_id) REFERENCES issues(id) ON DELETE CASCADE,
 FOREIGN KEY(item_id) REFERENCES items(id), FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE SET NULL
);

CREATE TABLE returns(
 id INT AUTO_INCREMENT PRIMARY KEY, return_no VARCHAR(50) UNIQUE NOT NULL,
 return_date DATE NOT NULL, issue_id INT NULL, returned_by VARCHAR(180),
 condition_status VARCHAR(40) DEFAULT 'Good', remarks TEXT, created_by INT NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(issue_id) REFERENCES issues(id) ON DELETE SET NULL,
 FOREIGN KEY(created_by) REFERENCES users(id)
);
CREATE TABLE return_lines(
 id INT AUTO_INCREMENT PRIMARY KEY, return_id INT NOT NULL, item_id INT NOT NULL,
 asset_id INT NULL, qty DECIMAL(12,2) NOT NULL,
 FOREIGN KEY(return_id) REFERENCES returns(id) ON DELETE CASCADE,
 FOREIGN KEY(item_id) REFERENCES items(id), FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE SET NULL
);

CREATE TABLE gate_passes(
 id INT AUTO_INCREMENT PRIMARY KEY, gatepass_no VARCHAR(50) UNIQUE NOT NULL,
 pass_date DATE NOT NULL, direction ENUM('Outward','Inward') NOT NULL DEFAULT 'Outward',
 recipient_vendor VARCHAR(180), purpose TEXT, vehicle_no VARCHAR(60),
 authorized_by VARCHAR(150), expected_return DATE NULL, remarks TEXT,
 created_by INT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(created_by) REFERENCES users(id)
);
CREATE TABLE gatepass_lines(
 id INT AUTO_INCREMENT PRIMARY KEY, gatepass_id INT NOT NULL, item_id INT NOT NULL,
 asset_id INT NULL, qty DECIMAL(12,2) NOT NULL, serial_no VARCHAR(150),
 FOREIGN KEY(gatepass_id) REFERENCES gate_passes(id) ON DELETE CASCADE,
 FOREIGN KEY(item_id) REFERENCES items(id), FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE SET NULL
);

CREATE TABLE urgent_purchases(
 id INT AUTO_INCREMENT PRIMARY KEY, urgent_no VARCHAR(50) UNIQUE NOT NULL,
 purchase_date DATE NOT NULL, item_description TEXT NOT NULL, qty DECIMAL(12,2) NOT NULL,
 vendor_id INT NULL, amount DECIMAL(14,2) DEFAULT 0, reason TEXT, remarks TEXT,
 created_by INT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(vendor_id) REFERENCES vendors(id) ON DELETE SET NULL,
 FOREIGN KEY(created_by) REFERENCES users(id)
);

CREATE TABLE documents(
 id INT AUTO_INCREMENT PRIMARY KEY, module VARCHAR(50) NOT NULL, record_id INT NOT NULL,
 doc_type VARCHAR(80) NOT NULL, original_name VARCHAR(255) NOT NULL,
 stored_name VARCHAR(255) NOT NULL, mime_type VARCHAR(120), uploaded_by INT NOT NULL,
 uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(uploaded_by) REFERENCES users(id)
);
CREATE TABLE number_sequences(
 id INT AUTO_INCREMENT PRIMARY KEY, fy VARCHAR(7) NOT NULL,
 module VARCHAR(20) NOT NULL, last_no INT NOT NULL DEFAULT 0,
 UNIQUE KEY uq_fy_module(fy,module)
);
CREATE TABLE audit_logs(
 id BIGINT AUTO_INCREMENT PRIMARY KEY, user_id INT NULL, action VARCHAR(120) NOT NULL,
 module VARCHAR(80), record_id INT NULL, details TEXT,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
);
