MEIL IT STORE MANAGEMENT SYSTEM
================================

REQUIREMENTS
- XAMPP for Windows
- PHP 8.1+ recommended
- MySQL/MariaDB
- Apache and MySQL enabled

INSTALLATION
1. Extract the folder "meil_it_store" into C:\xampp\htdocs\
2. Open XAMPP Control Panel and start Apache and MySQL.
3. Open http://localhost/phpmyadmin
4. Import database.sql from this folder.
5. Open config/database.php and set DB credentials if needed.
   Default XAMPP credentials: user=root, password blank.
6. Open http://localhost/meil_it_store/
7. Initial login:
   Username: admin
   Password: password
8. Change the admin password immediately from User Management.

IMPORTANT
- This is a first usable release. Review the workflow with your company before official use.
- Set a strong database password and configure backups before using on a site LAN.
- For LAN access, use the host computer's LAN IP and restrict Apache/firewall access to the site network.
- Do not expose this application directly to the public internet.
- Uploaded documents are stored in uploads/ and are linked to their transaction.
- Keep the uploads folder writable by Apache.
- Back up both the MySQL database and uploads folder regularly.

FEATURES
Dashboard, item master, employee master, vendor master, indent with multiple line items,
IOC/procurement records, inward receipts, stock issue, returns, gate passes, urgent
purchase register, document attachments, transaction history and stock reports.

FINANCIAL YEAR
Indian financial year: 1 April to 31 March. Numbering resets independently by
transaction type each financial year.

SECURITY
The app uses password hashing, prepared statements, CSRF tokens, session checks,
file extension/MIME checks and randomized upload filenames. Use HTTPS and additional
server hardening before production deployment.
